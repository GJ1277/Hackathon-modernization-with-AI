import google.generativeai as genai
from flask import Flask, request, jsonify
from flask_cors import CORS

# 1. Setup Gemini
genai.configure(api_key="AIzaSyCNCL0Wk0cpzOtiVsreAdvgdmNF3JLWUPE")
model = genai.GenerativeModel('gemini-2.5-flash')

for m in genai.list_models():
  if 'generateContent' in m.supported_generation_methods:
    print(f"Available Model: {m.name}")

app = Flask(__name__)
CORS(app)

@app.route('/translate', methods=['POST'])
def translate():
    data = request.json
    cobol_code = data.get("code", "")
    
    # The "Prompt" tells the AI exactly what to do
    prompt = f"""
    You are an expert legacy code migration assistant. 
    Convert the following COBOL code into modern, clean Java code.
    Only return the Java code itself, no explanations.
    
    COBOL CODE:
    {cobol_code}
    """
    
    try:
        # 2. Ask Gemini to do the conversion
        response = model.generate_content(prompt)
        java_result = response.text
        
        # Cleanup: Remove java or  tags if the AI includes them
        java_result = java_result.replace("java", "").replace("", "")
        
        return jsonify({"java": java_result})
    except Exception as e:
        return jsonify({"java": f"// Error contacting AI: {str(e)}"})

if __name__ == '__main__':
    app.run(port=5000, debug=True)