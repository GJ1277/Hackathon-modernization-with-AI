import React, { useState } from 'react';
import Editor from '@monaco-editor/react';
import axios from 'axios';

function App() {
  const [cobolCode, setCobolCode] = useState('*> Type your COBOL code here\nIDENTIFICATION DIVISION.\nPROGRAM-ID. HELLO-WORLD.');
  const [javaCode, setJavaCode] = useState('// Java output will appear here');

  const handleTranslate = async () => {
    setJavaCode("// Translating...");
    try {
      // We will build this backend URL in the next phase
      const response = await axios.post('http://localhost:5000/translate', { code: cobolCode });
      setJavaCode(response.data.java);
    } catch (error) {
      setJavaCode("// Error: Could not connect to the backend logic.");
    }
  };

  return (
    <div style={{ backgroundColor: '#1e1e1e', color: 'white', minHeight: '100vh', padding: '20px' }}>
      <header style={{ textAlign: 'center', marginBottom: '20px' }}>
        <h1>COBOL ➔ Java Migrator</h1>
        <button 
          onClick={handleTranslate}
          style={{ padding: '10px 25px', fontSize: '16px', cursor: 'pointer', backgroundColor: '#007acc', color: 'white', border: 'none', borderRadius: '5px' }}
        >
          Convert Code
        </button>
      </header>

      <div style={{ display: 'flex', gap: '20px', height: '70vh' }}>
        <div style={{ flex: 1 }}>
          <h3>COBOL Source</h3>
          <Editor height="100%" theme="vs-dark" defaultLanguage="cobol" value={cobolCode} onChange={(val) => setCobolCode(val)} />
        </div>
        <div style={{ flex: 1 }}>
          <h3>Java Output</h3>
          <Editor height="100%" theme="vs-dark" defaultLanguage="java" value={javaCode} options={{ readOnly: true }} />
        </div>
      </div>
    </div>
  );
}

export default App;